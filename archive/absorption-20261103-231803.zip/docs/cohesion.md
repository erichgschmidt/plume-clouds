# Cohesion and restored expressive controls

These controls stay within the existing 2D footprint/height-field renderer. No meshes,
3D simulation, extra rendering passes, or new puff spawning are introduced.

## Temporary bonds

**Cohesion** pairs nearby, slowly separating root puffs. Each root has at most one
partner. Its existing children follow its changing position and size. The smaller
puff becomes a bulge on the larger one; the bond gradually releases after its
lifetime, excessive separation, or excessive relative speed. Released puffs may
form another bond after a cooldown. Capture and release each take two simulation
seconds. Playback speed and pause apply to the process.

- **Bond fusion** allows complete coalescence. With fusion and Cohesion
  both at 1, the donor shrinks to zero and the recipient holds the full combined area
  budget. The donor and its children return during release. Zero retains the original
  two-lobe behavior. During full fusion, a neck forms before area transfers from
  the donor.
- **Bond yield** controls partial bulging: up to 60% of the smaller root's area
  with fusion off. Increasing fusion blends toward complete donor absorption;
  full fusion does not require increasing yield.
- **Absorption ripple** gives capture one gentle response on the absorption side
  of the fused contour. Its strength then steadily decreases to rest, without
  reversing direction, bouncing, or recoiling.
  It receives no ongoing forcing and does not build energy before release.
  Zero gives quiet absorption. Both the editor default and isolated study use 0.65.
  The initial nudge peaks at the end of the two-second capture and retreats on
  the same side. At Ripple speed 1 it reaches zero by eight seconds
  after capture began. Changing the amount later does not retrigger the response.
- **Ripple speed** changes the pace of this transient response. It follows simulation
  time, so pause and playback speed still apply. It does not sustain motion after
  the response has settled or change the two-second capture. Reset the study to
  observe another capture.
- **Bond lifetime** is measured from capture, including the two-second entry.
- **Release speed** is relative speed, in reference radii per simulation second.
  Smaller thresholds make bonds easier to break and harder to capture.

Full fusion compensates for overlap using the union area of the two circular
footprints. Its target grows from their initial union area toward the sum of their
original circle areas. This avoids a temporary loss of mass as the circles overlap
and the donor is absorbed. The area-weighted center is maintained.

The sum of the **drawn** radii squared is not constant during overlap: temporary
radius compensation supplies the area hidden by that overlap. At complete fusion,
the final root radius squared equals the sum of the two original radii squared.
This is a circle-based area model, not a guarantee for the exact visible area of
deformed, noisy outlines or generated children. Simple equal-size and unequal-size
GPU cases showed no area dip greater than 0.01%; more elaborate shapes remain
outside that guarantee. No extra rendering pass or bridging orb is added.
Original root IDs and simulation buffers remain intact. This is reversible local
bonding, not permanent particle fusion or unrestricted chains of merged clouds.

The absorption ripple changes the recipient's existing contour harmonics, with an updated
conservative bound. The silhouette, surface normals, shadow membership and child
attachments therefore follow the same deformation. No extra visible orb or contact
shadow boundary is introduced. This is a bounded artistic 2D deformation with a
capture response that settles without oscillation, not a fluid or elastic-body
simulation. Its deformed outline's exact area can vary around the circle-based
area model described above.

The recipient is fixed for a bond's lifetime to prevent a pop when natural sizes
cross. Radius ratios above 3:1, reservoir roots, retiring roots, and nearly invisible
roots are excluded from capture. Matching considers at most 128 available roots.
With fusion off, maximum paired displacement is 0.6 times their summed natural radii.
Fusion expands this bound only as needed to reach the conserved centroid. If a partner
disappears, its survivor gradually returns to its natural size and path.

Start with Cohesion 0.65–0.85, Bond yield 0.5–0.75, lifetime 10–12 seconds, and release
speed 1 for bulging pairs. To see complete fusion, set Cohesion and Bond fusion
to 1; yield can stay at any value. The two-puff study starts with full-fusion settings
and a 14-second bond lifetime, leaving a quiet interval after the ripple. Press Play to
develop bonds. Turning Cohesion off releases existing bonds
gradually. Reset starts fresh. Timeline rewind clears bond history rather than
reconstructing past bonds; exact arbitrary-time replay is not implemented.
The ripple is evaluated from elapsed time since capture. It does not require a history
of wall collisions or continuous internal travel. This does not change the bond
history limitations described above.

## Restored controls

- **Contour cohesion** broadens local outline joins in rendering model 2 without
  widening pixel coverage or ownership tolerances. It closes small gaps, rather than
  merging whole disconnected forms. It is independent of attachment blending.
- **Shadow simplification** uses the broad cloud slope to quiet fine shading and
  texture in shadow-facing areas. Body softness sets its scale. It does not change
  coverage or geometry, and is not a replacement for contact/cavity correctness.
  If Body lighting was off, it enables the existing broad-slope accumulation cost.
- **Child deformation** scales children's own seeded irregularity independently
  of their parent's shape. Zero gives round children; attachment positions still
  follow the parent's deformed contour.
- **Deformation inheritance** blends each child's seeded shape toward its parent's
  deformation. Child deformation still controls its strength.

Defaults preserve the previous parameter behavior: Cohesion, contour cohesion,
shadow simplification, and inheritance are zero; child deformation is one.
Bond fusion also defaults to zero, preserving existing bonded-pair presets.
Absorption ripple defaults to 0.65 for fused looks. Explicitly saved zero stays zero.
The existing `bondAgitation` and `bondTempo` keys and saved numeric values are retained;
only their labels and the motion model change. Older fused looks now receive a
capture response that settles, rather than perpetual internal motion.
The preset schema fills missing values with the defaults above. In the sky editor,
bonding and child deformation are form settings; contour and shading are scene-wide.

## Isolated study and checks

Open `dist/plume-cohesion.html` for two persistent puffs without spawning, noise,
erosion, or camera sway. All three standalone pages are built by `tools/build-single.js`.

Node checks: `tools/cohesion-test.cjs` and `tools/tree-features-test.cjs` cover bond
state, conservation, identity, lifecycle, deformation inheritance and renderer upload.
`tools/cohesion-browser-test.cjs` exercises a complete rendered lifecycle; pass
`--bundle` to test the standalone study. It uses `PLAYWRIGHT_MODULE`, `CHROME_PATH`
and optional `CLOUD_TEST_URL` like the existing browser regression runner.
`tools/internal-motion-test.cjs --bundle` isolates fixed source roots so the capture
response can be distinguished from source motion, spawning, or changing radii.
`tools/parameters-ui-test.cjs` checks ripple labels, unchanged saved values,
dependencies, sky imports, and the study defaults.

The expressive GPU suite checks neutral settings, coverage validity, small-puff
cutoffs, shadow detail suppression and independence from attachment blend. These
tests do not establish that every noisy or strongly deformed combination is halo-free.
