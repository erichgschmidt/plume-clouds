/* Actual GPU coverage-area regression: conserving sum(radius²) does not conserve
 * a union's visible area while its discs overlap. Fixed roots isolate this case. */
'use strict';
const assert=require('node:assert/strict'),path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{
  const browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_PATH||undefined,args:['--enable-webgl','--ignore-gpu-blocklist']});
  try{
    const page=await browser.newPage({viewport:{width:1180,height:900}}),errors=[];
    page.on('pageerror',e=>errors.push(e.message));
    const url=process.argv.includes('--bundle')?pathToFileURL(path.resolve(__dirname,'../dist/plume-cohesion.html')).href:(process.env.CLOUD_TEST_URL||'http://127.0.0.1:8765')+'/cohesion-study.html';
    await page.goto(url);await page.waitForFunction(()=>window.cohesionStudy);await page.evaluate(()=>cohesionStudy.pause());
    const result=await page.evaluate(()=>{
      const cv=document.createElement('canvas');cv.width=512;cv.height=384;
      const R=new PuffRenderer(cv),gl=R.gl,checks=[],film=[];
      const look=Object.assign({},cohesionStudy.look,{modelVersion:2,cohesion:1,cohesionYield:1,bondMerge:1,bondLife:100,releaseSpeed:3,bondAgitation:0,bondTempo:1,
        children:0,shapeVar:0,angular:0,noise:0,noise2:0,windSpeed:0,erosion:0,wispAmount:0,contourFilter:0,contourCohesion:0,
        smooth:0,depth:1,panX:0,panY:0,zoom:1,contact:0,cavity:0,body:0,shadowQuiet:0});
      function check(name,ok,info){checks.push({name,ok,info});}
      function components(mask,w,h){const seen=new Uint8Array(mask.length),queue=new Int32Array(mask.length);let count=0;
        for(let i=0;i<mask.length;i++)if(mask[i]&&!seen[i]){count++;let head=0,tail=1;queue[0]=i;seen[i]=1;
          while(head<tail){const p=queue[head++],x=p%w,y=(p/w)|0;for(const q of [x?p-1:-1,x+1<w?p+1:-1,y?p-w:-1,y+1<h?p+w:-1])if(q>=0&&mask[q]&&!seen[q]){seen[q]=1;queue[tail++]=q;}}}
        return count;
      }
      function image(pixels){const c=document.createElement('canvas');c.width=R._w;c.height=R._h;const ctx=c.getContext('2d'),im=ctx.createImageData(c.width,c.height);
        for(let y=0;y<c.height;y++)im.data.set(pixels.subarray((c.height-y-1)*c.width*4,(c.height-y)*c.width*4),y*c.width*4);ctx.putImageData(im,0,0);return c.toDataURL();}
      function fixture(label,rows,ripple=0,separated=false){
        R._bondStates=new WeakMap();R._wind=[];
        look.bondAgitation=ripple;
        const sim={time:0,seed:1,cx:.5,baseY:.65,topY:.18,refRadius:.12,blobCount:2,baseStart:2,blobs:new Float32Array(rows),
          aux:new Float32Array([0,.5,0,1,0,.5,0,1]),spin:new Float32Array([0,0,1,0,0,0,1,0]),detail:new Float32Array([1,1])};
        const frames=[];let invalid=0;
        for(let j=0;j<=(ripple?100:30);j++){
          sim.time=j/10;R.render(sim,look,sim.time);
          const n=R._w*R._h,field=new Float32Array(n*4),gradient=new Float32Array(n*4),pixels=new Uint8Array(n*4);
          gl.readPixels(0,0,R._w,R._h,gl.RGBA,gl.UNSIGNED_BYTE,pixels);gl.bindFramebuffer(gl.FRAMEBUFFER,R._fbo);
          gl.readBuffer(gl.COLOR_ATTACHMENT0);gl.readPixels(0,0,R._w,R._h,gl.RGBA,gl.FLOAT,field);
          gl.readBuffer(gl.COLOR_ATTACHMENT3);gl.readPixels(0,0,R._w,R._h,gl.RGBA,gl.FLOAT,gradient);
          gl.readBuffer(gl.COLOR_ATTACHMENT0);gl.bindFramebuffer(gl.FRAMEBUFFER,null);
          let area=0,binaryArea=0;const mask=new Uint8Array(n);
          // Field alpha also stores interior distance above1; clamp to recover coverage.
          for(let p=0;p<n;p++){const k=p*4;area+=Math.min(1,Math.max(0,field[k+3]));if(field[k+3]>=.5){mask[p]=1;binaryArea++;if(!Number.isFinite(field[k])||!Number.isFinite(gradient[k])||!Number.isFinite(gradient[k+1]))invalid++;}}
          frames.push({time:sim.time,area,binaryArea,components:components(mask,R._w,R._h),packed:R.count,donorRadius:R.count>1?R._sphData[6]:0});
          if(label==='unequal'&&[0,5,10,15,20,30].includes(j))film.push({time:sim.time,url:image(pixels)});
        }
        const start=frames[0].area,min=Math.min(...frames.map(f=>f.area));let maxDrawdown=0,peak=start;
        for(const f of frames){peak=Math.max(peak,f.area);maxDrawdown=Math.max(maxDrawdown,(peak-f.area)/start);}
        check(label+': visible area never dips below starting coverage',min/start>=.995,{start,min,ratio:min/start});
        check(label+': no mid-merge visual shrink after area growth',maxDrawdown<=.005,{maxDrawdown});
        const firstJoined=frames.findIndex(f=>f.components===1);
        check(label+': connected neck remains connected after contact',firstJoined>=0&&frames.slice(firstJoined).every(f=>f.components===1),{firstContact:firstJoined>=0?frames[firstJoined].time:null});
        if(separated){
          check(label+': starts as two separate components',frames[0].components===2);
          const initialDonor=frames[0].donorRadius,preContact=frames.slice(0,firstJoined),minDonor=Math.min(...preContact.map(f=>f.donorRadius));
          check(label+': donor does not shrink before a visible neck forms',firstJoined>0&&minDonor>=initialDonor*.999,{initialDonor,minDonor,firstContact:frames[firstJoined]?.time});
        }
        if(ripple){const late=frames.filter(f=>f.time>=2),latePeak=Math.max(...late.map(f=>f.area)),lateDrop=(latePeak-late.at(-1).area)/late.at(-1).area;
          check(label+': ripple settlement does not visibly shrink the merged body',lateDrop<=.005,{latePeak,restArea:late.at(-1).area,lateDrop});}
        check(label+': final shape is one packed parent',frames.at(-1).packed===1);
        check(label+': covered field and slopes remain finite',invalid===0,{invalid});
        return {label,frames};
      }
      const fixtures=[fixture('unequal',[.43,.40,.145,17,.65,.40,.09,29]),fixture('equal',[.40,.40,.12,17,.63,.40,.12,29]),
        fixture('default ripple',[.43,.40,.145,17,.65,.40,.09,29],.65),fixture('separated',[.43,.40,.145,17,.72375,.40,.09,29],0,true)];
      return {checks,fixtures,film};
    });
    if(process.env.COALESCENCE_SCREENSHOT){await page.evaluate(async film=>{
      const host=document.createElement('div');host.style.cssText='position:fixed;inset:0;z-index:9999;background:#202629;color:white;padding:14px;font:16px system-ui;overflow:auto';
      host.textContent='2D coalescence · unequal discs · no noise, children, deformation or ripple';const grid=document.createElement('div');grid.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:12px';host.appendChild(grid);
      await Promise.all(film.map(f=>new Promise(resolve=>{const box=document.createElement('div'),label=document.createElement('div'),im=document.createElement('img');label.textContent=f.time+' seconds';im.style.cssText='width:100%;image-rendering:pixelated';im.onload=resolve;im.src=f.url;box.append(label,im);grid.appendChild(box);})));document.body.appendChild(host);
    },result.film);await page.screenshot({path:process.env.COALESCENCE_SCREENSHOT});}
    console.log(JSON.stringify({checks:result.checks,fixtures:process.argv.includes('--verbose')?result.fixtures:undefined}));
    assert.deepEqual(errors,[]);if(process.argv.includes('--bundle'))assert.equal(await page.locator('script[src]').count(),0);
    assert.deepEqual(result.checks.filter(c=>!c.ok),[]);console.log('Coalescence GPU: PASS ('+result.checks.length+' checks)');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
