'use strict';
const assert=require('node:assert/strict');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{
  const browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_PATH||undefined,args:['--enable-webgl','--ignore-gpu-blocklist']});
  try{
    const page=await browser.newPage({viewport:{width:1100,height:800}}),errors=[];
    page.on('pageerror',e=>errors.push(e.message));
    const url=process.argv.includes('--bundle')?pathToFileURL(path.resolve(__dirname,'../dist/plume-cohesion.html')).href:(process.env.CLOUD_TEST_URL||'http://127.0.0.1:8765')+'/cohesion-study.html';
    await page.goto(url);await page.waitForFunction(()=>window.cohesionStudy);
    await page.evaluate(()=>{cohesionStudy.pause();cohesionStudy.reset();});
    const cycle=await page.evaluate(()=>{
      const s=cohesionStudy;
      function union(a){
        const r=a[2],q=a[6],d=Math.hypot(a[4]-a[0],a[5]-a[1]),total=r*r+q*q;
        if(d>=r+q)return total;if(d<=Math.abs(r-q))return Math.max(r*r,q*q);
        const ac=v=>Math.acos(Math.max(-1,Math.min(1,v)));
        const lens=r*r*ac((d*d+r*r-q*q)/(2*d*r))+q*q*ac((d*d+q*q-r*r)/(2*d*q))-.5*Math.sqrt(Math.max(0,(-d+r+q)*(d+r-q)*(d-r+q)*(d+r+q)));
        return total-lens/Math.PI;
      }
      function run(dt){
        s.reset();const phases=new Set();let maxStep=0,last=null,maxAreaError=0,maxEndpointError=0,endpoints=0,peak=null;
        for(let i=0;i<Math.round(20/dt);i++){
          s.advance(dt);const engine=s.renderer._bondStates.get(s.sim),out=engine.update(s.sim,s.sim.time,s.look);
          for(const p of ['entering','bonded','releasing'])if(engine.stats[p])phases.add(p);
          const B=s.sim.blobs,area=B[2]*B[2]+B[6]*B[6],initial=union(B),w=out[3],ease=w*w*w*(w*(w*6-15)+10);
          maxAreaError=Math.max(maxAreaError,Math.abs(union(out)-(initial+ease*(area-initial))));
          if(w>=1-1e-7){endpoints++;maxEndpointError=Math.max(maxEndpointError,Math.abs(out[2]*out[2]+out[6]*out[6]-area));}
          if(last)for(const j of [0,1,2,4,5,6]){
            const delta=Math.abs(out[j]-last[j]);
            if(delta>maxStep){maxStep=delta;peak={time:s.sim.time,channel:j,phase:engine.stats.releasing?'releasing':engine.stats.entering?'entering':'bonded'};}
          }
          last=Array.from(out);
        }
        return {phases:Array.from(phases),maxStep,maxAreaError,maxEndpointError,endpoints,peak,maxSpeed:maxStep/dt};
      }
      const coarse=run(.02),fine=run(.01);
      s.reset();s.advance(3);
      return {coarse,fine,refinementRatio:fine.maxStep/coarse.maxStep};
    });
    for(const run of [cycle.coarse,cycle.fine]){
      assert.deepEqual(run.phases.sort(),['bonded','entering','releasing']);
      assert.ok(run.maxAreaError<1e-7,'analytic visible-union target follows the merge envelope');
      assert.ok(run.endpoints>0&&run.maxEndpointError<1e-7,'fully merged endpoint contains both original material budgets');
      // Full fusion moves the donor toward the mass centroid. A fixed .004-per-
      // frame cap confused its larger smooth motion with a discontinuity.
      assert.ok(run.maxSpeed<.3,'bounded full-merge/release velocity: '+run.maxSpeed);
    }
    assert.ok(cycle.refinementRatio>.4&&cycle.refinementRatio<.6,'halving dt must halve the largest step (a pop would not): '+cycle.refinementRatio);
    if(process.env.COHESION_SCREENSHOT)await page.screenshot({path:process.env.COHESION_SCREENSHOT});
    if(process.argv.includes('--bundle'))assert.equal(await page.locator('script[src]').count(),0);
    assert.deepEqual(errors,[]);
    console.log('Cohesion browser: complete cycle, bounded frame changes, area conservation, renderer and runtime PASS',cycle);
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
