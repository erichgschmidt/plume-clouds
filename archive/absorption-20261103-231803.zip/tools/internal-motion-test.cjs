/* Fixed roots isolate internal pressure from translation, spawning and radius changes.
 * Run with PLAYWRIGHT_MODULE / CHROME_PATH as in render-regression.cjs.
 * INTERNAL_MOTION_SCREENSHOT optionally writes a six-frame visual study.
 */
'use strict';
const assert=require('node:assert/strict');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
(async()=>{
  const browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_PATH||undefined,args:['--enable-webgl','--ignore-gpu-blocklist']});
  try{
    const page=await browser.newPage({viewport:{width:1180,height:900}}),errors=[];
    page.on('pageerror',e=>errors.push(e.message));
    const url=process.argv.includes('--bundle')?pathToFileURL(path.resolve(__dirname,'../dist/plume-cohesion.html')).href:(process.env.CLOUD_TEST_URL||'http://127.0.0.1:8765')+'/cohesion-study.html';
    await page.goto(url);
    await page.waitForFunction(()=>window.cohesionStudy);
    await page.evaluate(()=>{cohesionStudy.pause();cohesionStudy.reset();cohesionStudy.advance(3);});
    const result=await page.evaluate(()=>{
      const cv=document.createElement('canvas');cv.width=384;cv.height=320;
      const R=new PuffRenderer(cv),gl=R.gl,M=PuffRenderer.MAX_SPH;
      const base=Object.assign({},cohesionStudy.look,{modelVersion:2,cohesion:1,cohesionYield:1,bondMerge:1,bondLife:100,releaseSpeed:3,
        children:0,shapeVar:0,angular:0,body:0,shadowQuiet:0,noise:0,noise2:0,windSpeed:0,erosion:0,wispAmount:0,
        contourFilter:0,contourCohesion:0,smooth:0,depth:1,panX:0,panY:0,zoom:1,bondTempo:1,contact:0,cavity:0});
      const raw=new Float32Array([.43,.40,.145,17,.65,.40,.09,29]);
      const mass=raw[2]*raw[2]+raw[6]*raw[6],cx=(raw[0]*raw[2]*raw[2]+raw[4]*raw[6]*raw[6])/mass,cy=raw[1];
      const checks=[],film=[];function check(name,ok,info){checks.push({name,ok,info});}
      function maskDiff(a,b){let changed=0;for(let i=3;i<a.length;i+=4)if((a[i]>=.5)!==(b[i]>=.5))changed++;return changed;}
      function exact(a,b){return a.length===b.length&&a.every((v,i)=>v===b[i]);}
      function pixelsDiff(a,b){let max=0;for(let i=0;i<a.length;i++)max=Math.max(max,Math.abs(a[i]-b[i]));return max;}
      function image(pixels){const c=document.createElement('canvas');c.width=cv.width;c.height=cv.height;const ctx=c.getContext('2d'),im=ctx.createImageData(c.width,c.height);
        for(let y=0;y<c.height;y++)im.data.set(pixels.subarray((c.height-y-1)*c.width*4,(c.height-y)*c.width*4),y*c.width*4);ctx.putImageData(im,0,0);return c.toDataURL();}
      function run(amount,shutoff=false){
        R._bondStates=new WeakMap();R._wind=[];
        const s={time:0,seed:1,cx:.5,baseY:.65,topY:.18,refRadius:.12,blobCount:2,baseStart:2,blobs:raw.slice(),
          aux:new Float32Array([0,.5,0,1,0,.5,0,1]),spin:new Float32Array([0,0,1,0,0,0,1,0]),detail:new Float32Array([1,1])};
        const look=Object.assign({},base,{bondAgitation:amount});R.render(s,look,0);
        const engine=R._bondStates.get(s);let maxAreaError=0,maxPoseError=0,invalid=0,maxShadowChange=0,maxPressureStep=0,previousPressure=null;
        function step(to){while(s.time<to-1e-9){s.time=Math.min(to,+(s.time+.05).toFixed(8));const out=engine.update(s,s.time,look);
          const p=engine.pressures&&Array.from(engine.pressures.values())[0],v=p?[p.x*p.amount,p.y*p.amount]:[0,0];
          if(previousPressure)maxPressureStep=Math.max(maxPressureStep,Math.hypot(v[0]-previousPressure[0],v[1]-previousPressure[1]));previousPressure=v;
          // Intermediate disc areas intentionally overlap; coalescence-test measures
          // their actual GPU union. The radius-squared sum is valid at full fusion.
          if(s.time>=3)maxAreaError=Math.max(maxAreaError,Math.abs(out[2]*out[2]+out[6]*out[6]-mass));}}
        function capture(){R.render(s,look,s.time);const n=R._w*R._h*4,field=new Float32Array(n),gradient=new Float32Array(n),pixels=new Uint8Array(n);
          gl.readPixels(0,0,R._w,R._h,gl.RGBA,gl.UNSIGNED_BYTE,pixels);gl.bindFramebuffer(gl.FRAMEBUFFER,R._fbo);
          gl.readBuffer(gl.COLOR_ATTACHMENT0);gl.readPixels(0,0,R._w,R._h,gl.RGBA,gl.FLOAT,field);
          gl.readBuffer(gl.COLOR_ATTACHMENT3);gl.readPixels(0,0,R._w,R._h,gl.RGBA,gl.FLOAT,gradient);
          gl.readBuffer(gl.COLOR_ATTACHMENT0);gl.bindFramebuffer(gl.FRAMEBUFFER,null);
          for(let i=0;i<n;i+=4)if(field[i+3]>=.5&&(!Number.isFinite(field[i])||!Number.isFinite(gradient[i])||!Number.isFinite(gradient[i+1])))invalid++;
          let packedArea=0;for(let i=0;i<R.count;i++)packedArea+=R._sphData[i*4+2]**2;
          if(s.time>=3)maxAreaError=Math.max(maxAreaError,Math.abs(packedArea-mass));
          if(s.time>=3)maxPoseError=Math.max(maxPoseError,Math.abs(R._sphData[0]-cx),Math.abs(R._sphData[1]-cy),Math.abs(R._sphData[2]-Math.sqrt(mass)));
          return {time:s.time,count:R.count,field,pixels,pose:Array.from(R._sphData.subarray(0,R.count*4)),coefficients:Array.from(R._sphData.subarray(M*24,M*24+4))};
        }
        const frames=[];for(const t of [1,1.5,2,3,4,6,8,10,12]){
          step(t);const f=capture();frames.push(f);
          if(t===1.5){
            const paused=capture();check('active ripple freezes at unchanged time ('+amount+', shutoff '+shutoff+')',exact(f.field,paused.field)&&exact(f.pixels,paused.pixels));
            if(shutoff){look.bondAgitation=0;const edited=capture();check('disabling ripple while paused does not pop',exact(f.field,edited.field)&&exact(f.pixels,edited.pixels));}
          }
          if(amount&&f.count===1){look.contact=1;look.cavity=1;const shadowed=capture();maxShadowChange=Math.max(maxShadowChange,pixelsDiff(f.pixels,shadowed.pixels));look.contact=0;look.cavity=0;}
          if(amount&&!shutoff&&[1,2,3,4,6,8].includes(t))film.push({time:t,url:image(f.pixels)});
        }
        const last=frames.at(-1),paused=capture();
        check('same-time rendering is frozen (agitation '+amount+')',exact(last.field,paused.field)&&exact(last.pixels,paused.pixels));
        check('full fusion keeps one packed root (agitation '+amount+')',frames.filter(f=>f.time>=3).every(f=>f.count===1),frames.map(f=>f.count));
        check('root centre and radius stay fixed (agitation '+amount+')',maxPoseError<1e-7,{maxPoseError});
        check('fully fused root area budget is conserved (agitation '+amount+')',maxAreaError<1e-7,{maxAreaError});
        check('field and slope remain finite (agitation '+amount+')',invalid===0,{invalid});
        const rest=frames.filter(f=>f.time>=8),motion=rest.map(f=>maskDiff(last.field,f.field));
        check('absorption settles without ongoing forcing ('+amount+', shutoff '+shutoff+')',rest.every(f=>f.coefficients.every(v=>Math.abs(v)<1e-5))&&motion.every(n=>n===0),{motion,coefficients:rest.map(f=>f.coefficients)});
        check('pressure changes continuously ('+amount+', shutoff '+shutoff+')',maxPressureStep<.10,{maxPressureStep});
        if(amount)check('contact/cavity do not outline the single pressured mass',maxShadowChange<=1,{maxChannelChange:maxShadowChange});
        check('source simulation records remain unchanged',exact(s.blobs,raw));
        return frames;
      }
      const neutral=run(0),active=run(1);run(1,true);
      let covered=0;for(let i=3;i<neutral.at(-1).field.length;i+=4)if(neutral.at(-1).field[i]>=.5)covered++;
      const changes=active.map((f,i)=>({time:f.time,relative:maskDiff(f.field,neutral[i].field)/covered}));
      const peak=Math.max(...changes.filter(f=>f.time<=4).map(f=>f.relative));
      check('early absorption has visible but gentle additional deformation',peak>.015&&peak<.20,{peak,changes});
      check('settled shape matches zero-ripple baseline exactly',active.filter(f=>f.time>=8).every(f=>exact(f.field,neutral.find(n=>n.time===f.time).field)));
      check('ripple does not alter packed root positions, radii or count',active.every((f,i)=>exact(f.pose,neutral[i].pose)));
      return {ok:checks.every(q=>q.ok),checks,film};
    });
    if(process.env.INTERNAL_MOTION_SCREENSHOT){
      await page.evaluate(async film=>{
        const host=document.createElement('div');host.style.cssText='position:fixed;inset:0;z-index:9999;background:#202629;color:white;padding:14px;font:16px system-ui;overflow:auto';
        const title=document.createElement('div');title.textContent='One gentle absorption ripple → rest · fixed source roots, conserved area';host.appendChild(title);
        const grid=document.createElement('div');grid.style.cssText='display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:12px';host.appendChild(grid);
        const loads=film.map(f=>new Promise(resolve=>{const fig=document.createElement('div'),label=document.createElement('div'),im=document.createElement('img');label.textContent=f.time+' seconds';im.style.cssText='width:100%;image-rendering:pixelated';im.onload=resolve;im.src=f.url;fig.append(label,im);grid.appendChild(fig);}));
        document.body.appendChild(host);await Promise.all(loads);
      },result.film);
      await page.screenshot({path:process.env.INTERNAL_MOTION_SCREENSHOT});
    }
    assert.deepEqual(errors,[],'Browser runtime errors');
    if(process.argv.includes('--bundle'))assert.equal(await page.locator('script[src]').count(),0);
    const failed=result.checks.filter(q=>!q.ok);assert.deepEqual(failed,[],JSON.stringify(failed));
    console.log('Internal motion: PASS ('+result.checks.length+' checks)',JSON.stringify(result.checks));
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
