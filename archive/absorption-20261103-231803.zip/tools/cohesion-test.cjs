'use strict';
const assert = require('node:assert/strict');
const CloudCohesion = require('../src/cohesion.js');
function sim(rows) {
  return { blobs: new Float32Array(rows.flat()), aux: new Float32Array(rows.flatMap(() => [0, .5, 0, 1])),
    blobCount: rows.length, baseStart: rows.length, refRadius: .1, parcels: [] };
}
const pair = () => sim([[.4, .5, .1, 11], [.57, .5, .09, 22]]);
const opts = { cohesion: 1, cohesionYield: .7, bondLife: 100, releaseSpeed: 1 };
const near = (a, b, e = 1e-6) => assert.ok(Math.abs(a - b) <= e, `${a} != ${b}`);
// Independent two-circle union oracle, in area / pi units. Mid-merge overlapping
// discs must not count their shared lens twice.
function unionArea(x1, y1, r1, x2, y2, r2) {
  const d = Math.hypot(x2 - x1, y2 - y1), total = r1 * r1 + r2 * r2;
  if (d >= r1 + r2) return total;
  if (d <= Math.abs(r1 - r2)) return Math.max(r1 * r1, r2 * r2);
  const angle = v => Math.acos(Math.max(-1, Math.min(1, v)));
  const lens = r1 * r1 * angle((d * d + r1 * r1 - r2 * r2) / (2 * d * r1)) +
    r2 * r2 * angle((d * d + r2 * r2 - r1 * r1) / (2 * d * r2)) -
    .5 * Math.sqrt(Math.max(0, (-d + r1 + r2) * (d + r1 - r2) * (d - r1 + r2) * (d + r1 + r2)));
  return total - lens / Math.PI;
}
const unionOf = a => unionArea(a[0], a[1], a[2], a[4], a[5], a[6]);
const blendEase = w => w * w * w * (w * (w * 6 - 15) + 10);
near(unionArea(0, 0, 1, 3, 0, 1), 2); near(unionArea(0, 0, 1, 0, 0, .5), 1);
near(unionArea(0, 0, 1, 1, 0, 1), 1.6089977810442293, 1e-12);
function advance(c, s, from, to, o = opts) { let out; for (let t = from; t <= to + 1e-9; t += .05) out = c.update(s, +t.toFixed(7), o); return out; }
function byId(s, out) { return new Map(Array.from({ length: s.blobCount }, (_, i) => [s.blobs[i * 4 + 3], Array.from(out.slice(i * 4, i * 4 + 4))])); }
{
  const s = pair(), c = new CloudCohesion(), before = Array.from(s.blobs), aux = Array.from(s.aux);
  for (const t of [0, 1, 20]) {
    const out = c.update(s, t, {});
    for (let i = 0; i < s.blobCount; i++) assert.deepEqual(Array.from(out.slice(i * 4, i * 4 + 4)), [...before.slice(i * 4, i * 4 + 3), 0]);
  }
  advance(c, s, 20, 23);
  assert.deepEqual(Array.from(s.blobs), before); assert.deepEqual(Array.from(s.aux), aux);
}
{
  const s = pair(), c = new CloudCohesion();
  c.update(s, 0, opts);
  const start = c.update(s, 0, opts), out = advance(c, s, .05, 3);
  assert.notDeepEqual(out, start); assert.equal(c.stats.bondCount, 1);
  const a = s.blobs[2] ** 2, b = s.blobs[6] ** 2, total = a + b;
  near(out[2] ** 2 + out[6] ** 2, total);
  for (const axis of [0, 1]) near((out[axis] * out[2] ** 2 + out[4 + axis] * out[6] ** 2) / total, (s.blobs[axis] * a + s.blobs[4 + axis] * b) / total);
  for (let i = 0; i < 2; i++) assert.ok(Math.hypot(out[i * 4] - s.blobs[i * 4], out[i * 4 + 1] - s.blobs[i * 4 + 1]) <= .6 * (s.blobs[2] + s.blobs[6]) + 1e-6);
  assert.deepEqual(c.update(s, 3, opts), out, 'same time is frozen');
  assert.deepEqual(c.update(s, 0, opts), new CloudCohesion().update(s, 0, opts), 'rewind restarts deterministically');
}
{
  const rows = [[.3, .5, .1, 5], [.46, .5, .1, 2], [.62, .5, .1, 9], [.78, .5, .1, 7]];
  const a = sim(rows), b = sim([rows[3], rows[1], rows[0], rows[2]]), ca = new CloudCohesion(), cb = new CloudCohesion();
  const oa = advance(ca, a, 0, 3), ob = advance(cb, b, 0, 3);
  assert.deepEqual(byId(a, oa), byId(b, ob), 'upload ordering does not change pairing');
  assert.ok(ca.stats.bondCount <= 2, 'at most one partner per root');
  const massIn = rows.reduce((v, r) => v + r[2] ** 2, 0);
  near(Array.from({ length: 4 }, (_, i) => oa[i * 4 + 2] ** 2).reduce((a, b) => a + b), massIn);
}
{
  const s = pair(), c = new CloudCohesion(); advance(c, s, 0, 3);
  s.blobs[4] += .04; c.update(s, 3.05, opts);
  assert.equal(c.stats.releasing, 1, 'fast separating roots release');
  advance(c, s, 3.1, 5.1); assert.equal(c.stats.bondCount, 0);
  c.update(s, 6, opts); assert.equal(c.stats.bondCount, 0, 'cooldown prevents immediate rebond');
  c.update(s, 7.2, opts); assert.equal(c.stats.bondCount, 1, 'settled roots can rebond');
}
{
  const s = pair(), c = new CloudCohesion(); const before = advance(c, s, 0, 3);
  const off = { ...opts, cohesion: 0 };
  const first = c.update(s, 3.05, off);
  near(first[0], before[0]); near(first[2], before[2]);
  const end = advance(c, s, 3.1, 5.1, off);
  for (let i = 0; i < 2; i++) { near(end[i * 4], s.blobs[i * 4]); near(end[i * 4 + 2], s.blobs[i * 4 + 2]); }
  assert.equal(c.stats.bondCount, 0);
}
{
  const s = pair(), c = new CloudCohesion(); const before = advance(c, s, 0, 3);
  s.blobCount = 1; s.baseStart = 1;
  const first = c.update(s, 3.05, opts);
  near(first[0], before[0]); near(first[2], before[2]); assert.equal(c.stats.orphanCount, 1);
  const end = advance(c, s, 3.1, 5.1);
  near(end[0], s.blobs[0]); near(end[2], s.blobs[2]); assert.equal(c.stats.orphanCount, 0);
}
{
  const s = pair(), c = new CloudCohesion();
  advance(c, s, 0, 1, { ...opts, bondLife: .5 }); assert.equal(c.stats.releasing, 1, 'bond lifetime expires');
  const identical = sim([[.5, .5, .1, 1], [.5, .5, .1, 2]]);
  assert.ok(Array.from(advance(new CloudCohesion(), identical, 0, 3)).every(Number.isFinite), 'coincident roots remain finite');
  const reserved = pair(); reserved.baseStart = 1;
  const reserveState = new CloudCohesion(); advance(reserveState, reserved, 0, 3); assert.equal(reserveState.stats.bondCount, 0);
  const low = pair(); low.aux[7] = .01; const lowState = new CloudCohesion(); advance(lowState, low, 0, 3); assert.equal(lowState.stats.bondCount, 0);
  const retired = pair(); retired.parcels = [{ seed: 22, retire: true }]; const retiredState = new CloudCohesion(); advance(retiredState, retired, 0, 3); assert.equal(retiredState.stats.bondCount, 0);
  const ratio = pair(); ratio.blobs[6] = .02; const ratioState = new CloudCohesion(); advance(ratioState, ratio, 0, 3); assert.equal(ratioState.stats.bondCount, 0);
}
{
  const s = pair(), c = new CloudCohesion(), before = advance(c, s, 0, 3);
  const phase = JSON.stringify(c.stats);
  s.blobs[0] += .1; s.blobs[4] += .1;
  const translated = c.update(s, 3, opts);
  near(translated[0], before[0] + .1); near(translated[4], before[4] + .1);
  assert.equal(JSON.stringify(c.stats), phase, 'paused geometry edits do not advance the bond lifecycle');
  s.blobs[2] *= 1.2; s.blobs[6] *= 1.2;
  const resized = c.update(s, 3, opts);
  near(resized[2] ** 2 + resized[6] ** 2, s.blobs[2] ** 2 + s.blobs[6] ** 2);
  assert.deepEqual(c.update(s, 3, opts), resized, 'paused edited geometry remains idempotent');
  s.blobCount = 1;
  const missing = c.update(s, 3, opts);
  near(missing[0], s.blobs[0]); near(missing[2], s.blobs[2]);
  const resumed = c.update(s, 3.05, opts);
  near(resumed[0], missing[0]); near(resumed[2], missing[2]);
}
{
  const s = sim([[.4, .5, .100001, 1], [.57, .5, .1, 2]]), c = new CloudCohesion();
  const before = advance(c, s, 0, 3);
  s.blobs[2] = .099999;
  const after = c.update(s, 3.001, opts);
  near(after[2], before[2], 1e-4); near(after[6], before[6], 1e-4);
  near(after[0], before[0], 1e-4); near(after[4], before[4], 1e-4);
}
{
  // Exercise unequal sizes, strongly buried pairs, stretched release, and the
  // displacement limiter without relaxing area/centroid conservation.
  for (const ratio of [1, 1.5, 2.99]) for (const distance of [0, .2, .8, 1.299]) for (const yieldAmount of [0, .5, 1]) {
    const ra = .1, rb = ra / ratio, s = sim([[.4, .5, ra, 1], [.4 + distance * (ra + rb), .5, rb, 2]]);
    const c = new CloudCohesion(), o = { ...opts, cohesionYield: yieldAmount, releaseSpeed: 100 };
    c.update(s, 0, o); c.update(s, 2.1, o);
    s.blobs[4] = .4 + 1.65 * (ra + rb);
    const out = c.update(s, 2.2, o), area = s.blobs[2] ** 2 + s.blobs[6] ** 2;
    assert.ok(Array.from(out).every(Number.isFinite));
    near(out[2] ** 2 + out[6] ** 2, area);
    near((out[0] * out[2] ** 2 + out[4] * out[6] ** 2) / area,
      (s.blobs[0] * s.blobs[2] ** 2 + s.blobs[4] * s.blobs[6] ** 2) / area);
    for (let i = 0; i < 2; i++) assert.ok(Math.hypot(out[i * 4] - s.blobs[i * 4], out[i * 4 + 1] - s.blobs[i * 4 + 1]) <= .6 * (ra + rb) + 1e-6);
  }
  const s = pair(), c = new CloudCohesion(); s.seed = 1; advance(c, s, 0, 3);
  s.seed = 2;
  assert.deepEqual(c.update(s, 3, opts), new CloudCohesion().update(s, 3, opts), 'seed reset starts fresh');
  const moving = pair(), m = new CloudCohesion(); m.update(moving, 0, {});
  moving.blobs[4] += .03; m.update(moving, .05, opts);
  assert.equal(m.stats.bondCount, 0, 'fast relative movement cannot capture');
}
{
  const full = { ...opts, cohesionYield: 1, bondMerge: 1 };
  for (const swap of [false, true]) {
    const s = sim(swap ? [[.3, .5, .09, 1], [.545, .5, .1, 2]] : [[.3, .5, .1, 1], [.545, .5, .09, 2]]);
    const c = new CloudCohesion(), recipient = swap ? 1 : 0, donor = 1 - recipient;
    let prior = c.update(s, 0, full), largestStep = 0, previousUnion = unionOf(s.blobs);
    for (let k = 1; k <= 150; k++) {
      const out = c.update(s, k * .02, full);
      const area = s.blobs[2] ** 2 + s.blobs[6] ** 2, initialUnion = unionOf(s.blobs), currentUnion = unionOf(out);
      near(currentUnion, initialUnion + blendEase(out[3]) * (area - initialUnion), 1e-7);
      assert.ok(currentUnion >= initialUnion - 1e-8 && currentUnion >= previousUnion - 1e-8, 'entry never shrinks visible circle union');
      previousUnion = currentUnion;
      const drawingArea = out[2] ** 2 + out[6] ** 2;
      near((out[0] * out[2] ** 2 + out[4] * out[6] ** 2) / drawingArea, (s.blobs[0] * s.blobs[2] ** 2 + s.blobs[4] * s.blobs[6] ** 2) / area);
      if (out[3] <= .4) { assert.ok(out[2] >= s.blobs[2] - 1e-7); assert.ok(out[6] >= s.blobs[6] - 1e-7, 'donor does not shrink before a bridge forms'); }
      if (out[3] >= .4) assert.ok(Math.hypot(out[4] - out[0], out[5] - out[1]) <= out[2] + out[6] + 1e-7, 'bridge contact precedes donor transfer');
      for (let i = 0; i < 2; i++) largestStep = Math.max(largestStep, Math.hypot(out[i * 4] - prior[i * 4], out[i * 4 + 1] - prior[i * 4 + 1]), Math.abs(out[i * 4 + 2] - prior[i * 4 + 2]));
      prior = out;
    }
    assert.equal(prior[donor * 4 + 2], 0, 'full merge removes the donor radius');
    near(prior[recipient * 4 + 2] ** 2, s.blobs[2] ** 2 + s.blobs[6] ** 2);
    assert.ok(largestStep < .01, 'merge motion stays continuous');
    // The original recipient stays recipient even after becoming much smaller.
    s.blobs[recipient * 4 + 2] = .04; s.blobs[donor * 4 + 2] = .12;
    const changed = c.update(s, 3, full);
    assert.equal(changed[donor * 4 + 2], 0);
    near(changed[recipient * 4 + 2] ** 2, s.blobs[2] ** 2 + s.blobs[6] ** 2);
    const separated = advance(c, s, 3.05, 5.1, { ...full, cohesion: 0 });
    near(separated[2], s.blobs[2]); near(separated[6], s.blobs[6]);
  }
  const s = pair(), c = new CloudCohesion(); advance(c, s, 0, 3);
  const initial = c.update(s, 3, opts);
  const first = c.update(s, 3.05, full);
  near(first[2], initial[2]); near(first[6], initial[6]);
  const settled = advance(c, s, 3.1, 5.1, full);
  assert.equal(settled[6], 0, 'changing controls reaches an exact full-merge endpoint');
}
{
  // Include already-overlapping and deeply buried starts, not only disjoint
  // circles where initial union happens to equal the final material budget.
  for (const separation of [0, .035, .09, .17, .24, .21 * 1.299]) {
    const s = sim([[.4, .5, .12, 11], [.4 + separation, .5, .09, 22]]), c = new CloudCohesion();
    const o = { ...opts, cohesionYield: .5, bondMerge: 1 }, initial = unionOf(s.blobs), total = s.blobs[2] ** 2 + s.blobs[6] ** 2;
    let prior = initial; c.update(s, 0, o);
    for (let i = 1; i <= 150; i++) {
      const out = c.update(s, i * .02, o), actual = unionOf(out);
      near(actual, initial + blendEase(out[3]) * (total - initial), 1e-7);
      assert.ok(actual >= prior - 1e-8 && actual >= initial - 1e-8, 'overlapping entry preserves or increases visible material');
      if (out[3] <= .4) for (const r of [2, 6]) assert.ok(out[r] >= s.blobs[r] - 1e-7, 'early bridge forms without shrinking either circle');
      if (out[3] >= .4) assert.ok(Math.hypot(out[4] - out[0], out[5] - out[1]) <= out[2] + out[6] + 1e-7, 'even the maximum capture gap closes before transfer');
      prior = actual;
    }
    near(prior, total, 1e-7);
  }
}
{
  // Fusion is a direct merge control. Yield shapes the partial bulge mode,
  // but must not leave a second orb when full fusion is explicitly requested.
  for (const yieldAmount of [0, .5, 1]) {
    const s = pair(), c = new CloudCohesion();
    const out = advance(c, s, 0, 3, { ...opts, cohesionYield: yieldAmount, bondMerge: 1 });
    assert.equal(out[6], 0, 'full fusion overrides the partial-yield ceiling');
    near(out[2] ** 2, s.blobs[2] ** 2 + s.blobs[6] ** 2);
  }
  const a = pair(), b = pair(), ca = new CloudCohesion(), cb = new CloudCohesion();
  for (let i = 0; i < 80; i++) assert.deepEqual(ca.update(a, i * .05, opts), cb.update(b, i * .05, { ...opts, bondMerge: 0 }), 'zero fusion retains the legacy path exactly');
}
{
  // Production tree integration: a fully absorbed root and its recursive children
  // must leave the upload together, while the original simulation stays intact.
  const fs = require('node:fs'), path = require('node:path'), vm = require('node:vm');
  const env = { window: { CloudCohesion }, performance, Float32Array, Math };
  vm.createContext(env);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../src/puffs.js'), 'utf8'), env);
  const R = env.window.PuffRenderer, r = Object.create(R.prototype), s = pair();
  r._w = 1024; r._h = 768; r._sphData = new Float32Array(R.MAX_SPH * 32);
  r.gl = { activeTexture() {}, bindTexture() {}, texSubImage2D() {} }; r._bin = () => {};
  s.spin = new Float32Array([0, 0, 1, 0, 0, 0, 1, 0]); s.detail = new Float32Array([1, 1]);
  s.cx = .5; s.baseY = .7; s.topY = .3; s.time = 0;
  const cloud = { sim: s, look: { ...opts, cohesionYield: 1, bondMerge: 1, children: 3, levels: 2, ratio: .5, life: 0 } };
  function ids() { return Array.from({ length: r.count }, (_, i) => [r._sphData[R.MAX_SPH * 16 + i * 4], r._sphData[R.MAX_SPH * 16 + i * 4 + 1]]); }
  r._tree([cloud], 0);
  assert.ok(ids().some(v => v[0] === 22), 'donor starts in the tree');
  for (let i = 1; i <= 150; i++) { s.time = i * .02; r._tree([cloud], s.time); }
  assert.ok(ids().some(v => v[0] === 11), 'recipient remains');
  assert.ok(ids().every(v => v[0] !== 22 && v[1] !== 22), 'donor and descendants leave together');
  near(s.blobs[6], .09); assert.equal(s.blobCount, 2);
  cloud.look.cohesion = 0;
  for (let i = 1; i <= 110; i++) { s.time = 3 + i * .02; r._tree([cloud], s.time); }
  assert.ok(ids().some(v => v[0] === 22), 'donor returns on release');
  assert.ok(ids().some(v => v[1] === 22), 'donor children return with its restored radius');
}
{
  const active = { ...opts, bondMerge: 1, cohesionYield: 1, bondAgitation: .8, bondTempo: 1 };
  const s = pair(), c = new CloudCohesion(); c.update(s, 0, active);
  assert.ok(c.pressures instanceof Map, 'pressure map is exposed');
  let last = null, peak = null, maxVector = 0;
  for (let i = 1; i <= 1200; i++) {
    const out = c.update(s, i / 100, active), p = c.pressures.get(11);
    if (i >= 800) assert.ok(!p, 'one absorption event settles completely by eight seconds');
    if (!p) { last = null; continue; }
    assert.ok(Number.isFinite(p.x + p.y + p.amount));
    assert.ok(Math.hypot(p.x, p.y) <= 1 + 1e-7); assert.ok(p.amount >= 0 && p.amount <= 1);
    const magnitude = Math.hypot(p.x, p.y) * p.amount;
    if (magnitude > maxVector) { maxVector = magnitude; peak = { ...p, time: i / 100 }; }
    if (last) {
      assert.ok(Math.hypot(p.amount * p.x - last.amount * last.x, p.amount * p.y - last.amount * last.y) < .03, 'continuous pressure vector');
    }
    if (i > 200 && peak) {
      assert.ok(p.x * peak.x + p.y * peak.y >= -1e-10, 'absorption never rebounds to the opposite side');
      if (last) assert.ok(magnitude <= Math.hypot(last.x, last.y) * last.amount + 1e-10, 'after the nudge, pressure only relaxes');
    }
    if (i > 250) assert.equal(out[6], 0, 'pressure does not add another orb');
    last = { ...p };
  }
  assert.ok(maxVector > .4, 'a visible absorption nudge'); near(peak.time, 2, .03);
  function pressureAt(dt, agitation = .8, until = 2.5, tempo = 1) {
    const s = pair(), c = new CloudCohesion(), o = { ...active, bondAgitation: agitation, bondTempo: tempo };
    c.update(s, 0, o); for (let i = 1; i <= Math.round(until / dt); i++) c.update(s, i * dt, o);
    return { c, s, p: c.pressures.get(11), o };
  }
  const coarse = pressureAt(.02), fine = pressureAt(.01);
  for (const k of ['x', 'y', 'amount']) near(coarse.p[k], fine.p[k], 1e-6);
  const frozen = { ...coarse.p }; coarse.c.update(coarse.s, 2.5, coarse.o); assert.deepEqual(coarse.c.pressures.get(11), frozen);
  const orphan = pressureAt(.01), before = { ...orphan.p }; orphan.s.blobCount = 1;
  orphan.c.update(orphan.s, 2.51, active); assert.deepEqual(orphan.c.pressures.get(11), before, 'orphan keeps pressure at removal');
  advance(orphan.c, orphan.s, 2.56, 4.56, active); assert.ok(!orphan.c.pressures.has(11), 'orphan pressure fully relaxes');
  assert.ok(!pressureAt(.02, 0).p, 'agitation zero produces no pressure');
  const calm = pressureAt(.02, 0);
  assert.deepEqual(coarse.c.update(coarse.s, 2.5, coarse.o), calm.c.update(calm.s, 2.5, calm.o), 'pressure leaves packed root positions/radii unchanged');
  const replay = pressureAt(.02); replay.c.update(replay.s, 0, replay.o);
  for (let i = 1; i <= 125; i++) replay.c.update(replay.s, i * .02, replay.o);
  assert.deepEqual(replay.c.pressures.get(11), coarse.p, 'rewind replays pressure deterministically');
  const fast = pressureAt(.02, .8, 2, 2), normal = pressureAt(.02, .8, 2);
  assert.deepEqual(fast.p, normal.p, 'maximum tempo does not hide the ripple before fusion completes');
  assert.ok(!pressureAt(.02, .8, 5.1, 2).p, 'faster tempo settles sooner after fusion');
  function editedTempo(dt) {
    const s = pair(), c = new CloudCohesion(); c.update(s, 0, active);
    for (let i = 1; i <= Math.round(6 / dt); i++) {
      const t = +(i * dt).toFixed(7), tempo = t >= 3.5 ? .35 : t >= 2.5 ? 2 : 1;
      c.update(s, t, { ...active, bondTempo: tempo });
    }
    return c.pressures.get(11);
  }
  const slowEdit = editedTempo(.02), fineEdit = editedTempo(.01);
  for (const k of ['x', 'y', 'amount']) near(slowEdit[k], fineEdit[k], 1e-6);
  const huge = pair(), gap = new CloudCohesion(), gapOptions = { ...active, bondLife: 1e6 };
  gap.update(huge, 0, gapOptions); gap.update(huge, 100000, gapOptions);
  assert.equal(gap.pressures.size, 0, 'large seeks decay to rest, never restart an event');
  gap.update(huge, 100003, { ...gapOptions, bondAgitation: 1, bondTempo: .2 }); assert.equal(gap.pressures.size, 0, 'late control edits cannot re-excite settled material');
  const expires = pair(), exp = new CloudCohesion(); advance(exp, expires, 0, 12.5, { ...active, bondLife: 12 });
  assert.equal(exp.pressures.size, 0, 'bond expiry does not re-energize a settled ripple');
  const zeroMerge = new CloudCohesion(), natural = pair(); advance(zeroMerge, natural, 0, 4, opts);
  assert.equal(zeroMerge.pressures.size, 0, 'fusion off produces no pressure');
  const releaseBefore = { ...coarse.p };
  coarse.c.update(coarse.s, 2.51, { ...coarse.o, cohesion: 0 });
  const releaseFirst = coarse.c.pressures.get(11);
  assert.ok(Math.hypot(releaseFirst.x * releaseFirst.amount - releaseBefore.x * releaseBefore.amount, releaseFirst.y * releaseFirst.amount - releaseBefore.y * releaseBefore.amount) < .15);
  advance(coarse.c, coarse.s, 2.56, 4.56, { ...coarse.o, cohesion: 0 }); assert.equal(coarse.c.pressures.size, 0);
}
console.log('OK: cohesion lifecycle, full merge, one damped absorption ripple, quiet rest, and analytic clock refinement');
