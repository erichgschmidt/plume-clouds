/* Temporary, bounded 2D bonds between existing roots. No IDs, depth, or sim state change.
 * One instance per sim. update() returns an independent Float32Array packed
 * [x, y, radius, bond strength] per input root. At unchanged time, lifecycle,
 * weights and orbit freeze while current root poses/sizes still affect output.
 * A seed change, rewind, or reset() starts fresh.
 * Fusion compensates overlapping footprints rather than counting their area twice.
 * The final radius-squared budget and the area-weighted centre are retained.
 */
(function (root) {
  'use strict';
  var ENTER = 2, EXIT = 2, COOLDOWN = 2, MAX_ROOTS = 128;
  function clamp(v, a, b) { return Math.max(a, Math.min(b, v)); }
  function number(v, fallback) { return typeof v === 'number' && isFinite(v) ? v : fallback; }
  function ease(v) { v = clamp(v, 0, 1); return v * v * v * (v * (v * 6 - 15) + 10); }
  function hash(v) { var x = Math.sin(v * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); }
  function key(a, b) { return a < b ? a + ':' + b : b + ':' + a; }
  // Area of the visible union of two circular footprints, in radius-squared units.
  // Counting both full discs during overlap made a conserving transfer look smaller.
  function unionArea(a, b, d) {
    if (d >= a + b) return a * a + b * b;
    if (d <= Math.abs(a - b)) return Math.max(a * a, b * b);
    var aa = a * a, bb = b * b, dd = d * d;
    var lens = aa * Math.acos(clamp((dd + aa - bb) / (2 * d * a), -1, 1)) +
      bb * Math.acos(clamp((dd + bb - aa) / (2 * d * b), -1, 1)) -
      .5 * Math.sqrt(Math.max(0, (-d + a + b) * (d + a - b) * (d - a + b) * (d + a + b)));
    return aa + bb - lens / Math.PI;
  }
  function CloudCohesion() { this.reset(); }
  CloudCohesion.prototype.reset = function () {
    this._sim = null; this._seed = undefined; this._time = undefined;
    this._bonds = new Map(); this._orphans = new Map(); this._cooldown = new Map();
    this._previous = new Map();
    this.pressures = new Map(); // recipient ID -> continuous unit-disk position {x,y,amount}; do not normalize x/y
    this.stats = { bondCount: 0, entering: 0, bonded: 0, releasing: 0, orphanCount: 0 };
  };
  // Evaluate both partners together. Interpolating a common separation about the
  // conserved centroid avoids translating the whole cloud when area changes hands.
  function pose(a, b, bond, w) {
    var ma = a.r * a.r, mb = b.r * b.r, total = ma + mb;
    var aLarge = bond.recipient === a.id; // identity is latched: crossing sizes must not reverse the transfer
    var merge = bond.merge || 0, donor = aLarge ? mb : ma;
    var partial = Math.min(ma, mb) * .6 * bond.yield;
    // First bring two substantial lobes together. Transfer material only after
    // the neck has begun forming, instead of shrinking a still-exposed donor.
    var absorption = ease((w - .4) / .6);
    var transfer = merge > 0 ? (1 - merge) * partial * w + merge * donor * absorption : partial * w;
    var na = ma + (aLarge ? transfer : -transfer), nb = total - na;
    var ra = Math.sqrt(Math.max(0, na)), rb = Math.sqrt(Math.max(0, nb)), dx = b.x - a.x, dy = b.y - a.y;
    var distance = Math.hypot(dx, dy), angle = distance > 1e-8 ? Math.atan2(dy, dx) : bond.seed * Math.PI * 2;
    var joined = Math.min(distance, 0.65 * (ra + rb)); // already buried roots need not be pushed apart
    if (merge > 0) joined *= 1 - merge * w; // full fusion reaches one centroid independently of partial-bulge yield
    var d = distance + (joined - distance) * w;
    angle += bond.orbit * w * (1 - merge * w);
    var sx = Math.cos(angle) * d, sy = Math.sin(angle) * d;
    var cx = (a.x * ma + b.x * mb) / total, cy = (a.y * ma + b.y * mb) / total;
    if (merge > 0 && w > 0) {
      var initial = unionArea(a.r, b.r, distance), visible = unionArea(ra, rb, d);
      // Recover hidden overlap gradually into the shared visible mass. A common
      // radius scale retains the weighted centre, and reaches scale 1 at full fusion.
      var target = initial + (total - initial) * ease(merge * w);
      target = visible + merge * Math.max(0, target - visible);
      if (target > visible + total * 1e-10) {
        var lo = 1, hi = Math.sqrt(target / Math.max(ra * ra, rb * rb));
        for (var n = 0; n < 20; n++) {
          var mid = (lo + hi) * .5;
          if (unionArea(ra * mid, rb * mid, d) < target) lo = mid; else hi = mid;
        }
        var scale = (lo + hi) * .5; ra *= scale; rb *= scale;
      }
    }
    return { ax: cx - sx * nb / total, ay: cy - sy * nb / total, ar: ra,
      bx: cx + sx * na / total, by: cy + sy * na / total, br: rb };
  }
  function displacement(p, a, b) {
    return Math.max(Math.hypot(p.ax - a.x, p.ay - a.y), Math.hypot(p.bx - b.x, p.by - b.y));
  }
  function withinLimit(p, a, b, bond) {
    var limit = .6 * (a.r + b.r), merge = bond.merge || 0;
    if (!(merge > 0)) return displacement(p, a, b) <= limit;
    var ma = a.r * a.r, mb = b.r * b.r, cx = (a.x * ma + b.x * mb) / (ma + mb), cy = (a.y * ma + b.y * mb) / (ma + mb);
    // Full fusion must be able to reach the conserved centroid, even when the
    // latched recipient becomes smaller. Do not constrain an invisible donor.
    var la = limit + merge * Math.max(0, Math.hypot(cx - a.x, cy - a.y) - limit);
    var lb = limit + merge * Math.max(0, Math.hypot(cx - b.x, cy - b.y) - limit);
    return (p.ar <= 1e-8 || Math.hypot(p.ax - a.x, p.ay - a.y) <= la + 1e-12) &&
      (p.br <= 1e-8 || Math.hypot(p.bx - b.x, p.by - b.y) <= lb + 1e-12);
  }
  function setting(bond, name, target, time) {
    var changes = bond.changes || (bond.changes = {}), change = changes[name];
    if (!change || change.target !== target) change = changes[name] = { from: bond[name], target: target, start: time };
    bond[name] = change.from + (target - change.from) * ease((time - change.start) / ENTER);
  }
  function absorptionRipple(seed, time, agitation, tempo, dx, dy) {
    // One capture-triggered displacement, aligned with the donor's approach side.
    // The seed only varies the direction/damping slightly; it does not drive motion.
    var a = (Math.hypot(dx, dy) > 1e-8 ? Math.atan2(dy, dx) : seed * Math.PI * 2) + (hash(seed * 37 + 1) - .5) * .12;
    var magnitude = .92 + .06 * hash(seed * 19 + 3);
    return { x: 0, y: 0, axisX: Math.cos(a) * magnitude, axisY: Math.sin(a) * magnitude,
      damping: 1.35 + .15 * hash(seed * 11 + 2),
      updated: time, phase: 0, pressure: 0,
      agitation: agitation, agitationFrom: agitation, agitationTarget: agitation, agitationAt: time,
      tempo: tempo, tempoFrom: tempo, tempoTarget: tempo, tempoAt: time };
  }
  // Integral of the clamped quintic ease: continuous-rate edits can advance phase
  // exactly, without substeps, multiplying total elapsed time, or restarting it.
  function easeIntegral(u) { if (u <= 0) return 0; if (u >= 1) return u - .5; return u * u * u * u * (u * u - 3 * u + 2.5); }
  function tempoIntegral(p, a, b) {
    return p.tempoFrom * (b - a) + (p.tempoTarget - p.tempoFrom) * .5 *
      (easeIntegral((b - p.tempoAt) / .5) - easeIntegral((a - p.tempoAt) / .5));
  }
  function settleRipple(bond, time, agitation, tempo) {
    var p = bond.ripple, elapsed = Math.max(0, time - p.updated);
    if (!(elapsed > 0)) return p;
    // Tempo affects settling AFTER entry. Even tempo 2 leaves the first nudge
    // visible as the donor finishes being absorbed at the two-second mark.
    var from = Math.max(p.updated, bond.start + ENTER);
    if (time > from) p.phase = Math.min(6, p.phase + tempoIntegral(p, from, time));
    if (p.phase >= 6 - 1e-10) p.phase = 6;
    p.agitation = p.agitationFrom + (p.agitationTarget - p.agitationFrom) * ease((time - p.agitationAt) / 2);
    p.tempo = p.tempoFrom + (p.tempoTarget - p.tempoFrom) * ease((time - p.tempoAt) / .5);
    if (agitation !== p.agitationTarget) { p.agitationFrom = p.agitation; p.agitationTarget = agitation; p.agitationAt = time; }
    if (tempo !== p.tempoTarget) { p.tempoFrom = p.tempo; p.tempoTarget = tempo; p.tempoAt = time; }
    p.updated = time;
    var u = p.phase, response = ease((time - bond.start) / ENTER);
    if (u > 0) response = (1 + p.damping * u) * Math.exp(-p.damping * u);
    // Critical damping: zero velocity at the peak, then positive monotone
    // relaxation on the same side. No bounce, recoil, or repeated excitation.
    p.pressure = 1 - ease((u - 3) / 3);
    p.x = p.pressure > 0 ? p.axisX * response : 0; p.y = p.pressure > 0 ? p.axisY * response : 0;
    return p;
  }
  function write(out, r, x, y, radius, strength) {
    var i = r.i * 4; out[i] = x; out[i + 1] = y; out[i + 2] = radius; out[i + 3] = strength;
  }
  function release(bond, time, cooldown) {
    if (bond.phase === 'releasing') return;
    bond.phase = 'releasing'; bond.releaseAt = time; bond.releaseWeight = bond.weight;
    cooldown.set(bond.a, time + EXIT + COOLDOWN); cooldown.set(bond.b, time + EXIT + COOLDOWN);
  }
  CloudCohesion.prototype.update = function (sim, time, options) {
    options = options || {}; time = number(time, 0);
    if (this._sim !== sim || this._seed !== sim.seed || (this._time !== undefined && time < this._time)) this.reset();
    this._sim = sim; this._seed = sim.seed;
    var first = this._time === undefined, dt = first ? 0 : Math.max(0, time - this._time);
    var B = sim.blobs, A = sim.aux, count = Math.max(0, Math.min(number(sim.blobCount, B.length / 4) | 0, B.length / 4));
    var out = new Float32Array(count * 4), roots = new Map(), eligible = new Map(), retired = new Set();
    var stop = Math.min(count, number(sim.baseStart, count)), previous = this._previous;
    var amount = clamp(number(options.cohesion, 0), 0, 1), yieldAmount = clamp(number(options.cohesionYield, .5), 0, 1);
    var mergeAmount = clamp(number(options.bondMerge, 0), 0, 1);
    var agitation = clamp(number(options.bondAgitation, .65), 0, 1), tempo = clamp(number(options.bondTempo, 1), .2, 2);
    var life = Math.max(.1, number(options.bondLife, 12));
    var speedLimit = Math.max(0, number(options.releaseSpeed, 1)) * Math.max(1e-4, number(sim.refRadius, .1));
    if (sim.parcels) sim.parcels.forEach(function (p) { if (p.retire) retired.add(Math.fround(number(p.seed, p.id))); });
    for (var i = 0; i < count; i++) {
      var o = i * 4, x = number(B[o], 0), y = number(B[o + 1], 0), radius = Math.max(0, number(B[o + 2], 0)), id = B[o + 3];
      out[o] = x; out[o + 1] = y; out[o + 2] = radius;
      if (!isFinite(id) || roots.has(id) || radius <= 1e-5) continue;
      var prev = previous.get(id), r = { i: i, id: id, x: x, y: y, r: radius,
        vx: prev && dt > 0 ? (x - prev.x) / dt : 0, vy: prev && dt > 0 ? (y - prev.y) / dt : 0 };
      roots.set(id, r);
      if (i < stop && (!A || number(A[o + 3], 0) > .15) && !retired.has(id)) eligible.set(id, r);
    }
    // Paused UI edits re-evaluate geometry, but cannot capture/release/age bonds.
    var frozen = !first && dt === 0;
    var bonds = this._bonds, orphans = this._orphans, cooldown = this._cooldown;
    var oldPressures = this.pressures, pressures = this.pressures = new Map();
    if (!frozen) cooldown.forEach(function (until, id) { if (time >= until) cooldown.delete(id); });
    bonds.forEach(function (bond, id) {
      if (frozen) return;
      var a = eligible.get(bond.a), b = eligible.get(bond.b);
      if (!a || !b) {
        // The survivor keeps its last displacement/area contribution and returns
        // to its own trajectory smoothly; a missing root cannot retain a bond.
        [bond.a, bond.b].forEach(function (rid) {
          var r = roots.get(rid), last = bond.last && bond.last.get(rid);
          if (r && last && last.strength > 0) orphans.set(rid, { start: time, dx: last.dx, dy: last.dy,
            area: last.area, strength: last.strength, pressure: oldPressures.get(rid) });
          cooldown.set(rid, time + EXIT + COOLDOWN);
        });
        bonds.delete(id); return;
      }
      var dx = b.x - a.x, dy = b.y - a.y, dist = Math.hypot(dx, dy), sumR = a.r + b.r;
      var vx = b.vx - a.vx, vy = b.vy - a.vy, speed = Math.hypot(vx, vy);
      var expired = time - bond.start >= life;
      if (amount <= 0 || speed > speedLimit || dist > 1.7 * sumR || expired) {
        release(bond, expired ? Math.max(first ? time : time - dt, bond.start + life) : time, cooldown);
      }
      if (bond.phase === 'releasing') {
        bond.weight = bond.releaseWeight * (1 - ease((time - bond.releaseAt) / EXIT));
        if (time >= bond.releaseAt + EXIT) { bonds.delete(id); return; }
      } else {
        setting(bond, 'merge', mergeAmount, time);
        if (mergeAmount > 0 || bond.merge > 0) {
          // Finite-time quintic changes actually reach complete transfer; an
          // exponential approach would leave a tiny donor indefinitely.
          setting(bond, 'intensity', amount, time); setting(bond, 'yield', yieldAmount, time);
        } else {
          bond.intensity += (amount - bond.intensity) * (1 - Math.exp(-dt * 3));
          bond.yield += (yieldAmount - bond.yield) * (1 - Math.exp(-dt * 3));
          if (bond.changes) { delete bond.changes.intensity; delete bond.changes.yield; }
        }
        bond.weight = bond.intensity * ease((time - bond.start) / ENTER);
        bond.phase = time - bond.start < ENTER ? 'entering' : 'bonded';
        var angularFlow = dist > 1e-5 ? clamp((dx * vy - dy * vx) / (dist * dist), -.5, .5) : 0;
        // Bounded integration of relative flow plus a slow seeded wander. No wall clock.
        var rate = .15 * angularFlow + (bond.seed - .5) * .05;
        bond.orbit = clamp(bond.orbit + rate * dt, -.45, .45);
      }
    });
    var occupied = new Set();
    bonds.forEach(function (b) { occupied.add(b.a); occupied.add(b.b); });
    orphans.forEach(function (v, id) { occupied.add(id); });
    // Bounded all-pairs search over the normal root cap; deterministic sorted IDs
    // and a normalized-distance ranking make pairing independent of upload order.
    if (amount > 0 && !frozen) {
      var candidates = Array.from(eligible.values()).filter(function (r) { return !occupied.has(r.id) && !cooldown.has(r.id); });
      candidates.sort(function (a, b) { return a.id - b.id; }); candidates.length = Math.min(candidates.length, MAX_ROOTS);
      var edges = [];
      for (i = 0; i < candidates.length; i++) for (var j = i + 1; j < candidates.length; j++) {
        var a = candidates[i], b = candidates[j];
        if (Math.max(a.r, b.r) > 3 * Math.min(a.r, b.r)) continue;
        var d = Math.hypot(a.x - b.x, a.y - b.y) / (a.r + b.r);
        if (d > 1.3 || Math.hypot(a.vx - b.vx, a.vy - b.vy) > speedLimit) continue;
        edges.push({ a: a.id, b: b.id, score: d });
      }
      edges.sort(function (a, b) { return a.score - b.score || a.a - b.a || a.b - b.b; });
      edges.forEach(function (e) {
        if (bonds.size >= MAX_ROOTS / 2 || occupied.has(e.a) || occupied.has(e.b)) return;
        var a = eligible.get(e.a), b = eligible.get(e.b);
        var bond = { a: e.a, b: e.b, start: time, phase: 'entering', weight: 0, intensity: amount,
          recipient: a.r >= b.r ? a.id : b.id, yield: yieldAmount, merge: mergeAmount, orbit: 0, seed: hash(e.a * .71 + e.b * 1.37), last: new Map() };
        var receiver = bond.recipient === a.id ? a : b, donor = bond.recipient === a.id ? b : a;
        bond.ripple = absorptionRipple(bond.seed, time, agitation, tempo, donor.x - receiver.x, donor.y - receiver.y);
        bonds.set(key(e.a, e.b), bond); occupied.add(e.a); occupied.add(e.b);
      });
    }
    bonds.forEach(function (bond) {
      var a = eligible.get(bond.a), b = eligible.get(bond.b), w = bond.weight;
      if (!a || !b) {
        // A paused deletion already displays natural geometry. Remember that
        // visible result so resuming cannot resurrect an older orphan offset.
        if (frozen) bond.last.clear();
        return;
      }
      var internal = frozen ? bond.ripple : settleRipple(bond, time, agitation, tempo);
      if (!(w > 0)) return;
      var p = pose(a, b, bond, w);
      if (!withinLimit(p, a, b, bond)) {
        // Limit the material blend itself, not the two offsets independently:
        // area and centroid conservation still hold at the displacement limit.
        var lo = 0, hi = w;
        for (var k = 0; k < 14; k++) {
          var mid = (lo + hi) * .5;
          if (withinLimit(pose(a, b, bond, mid), a, b, bond)) lo = mid; else hi = mid;
        }
        w = lo; p = pose(a, b, bond, w);
      }
      write(out, a, p.ax, p.ay, p.ar, w); write(out, b, p.bx, p.by, p.br, w);
      var pressureAmount = clamp(internal.pressure * (bond.merge || 0) * w * internal.agitation, 0, 1);
      if (pressureAmount > 1e-8) {
        var px = internal.x, py = internal.y;
        if (bond.phase === 'releasing') {
          var donor = bond.recipient === a.id ? b : a, receiver = bond.recipient === a.id ? a : b;
          var dx = donor.x - receiver.x, dy = donor.y - receiver.y, span = Math.max(a.r + b.r, Math.hypot(dx, dy), 1e-6);
          var exit = ease((time - bond.releaseAt) / EXIT);
          px += (.85 * dx / span - px) * exit; py += (.85 * dy / span - py) * exit;
        }
        pressures.set(bond.recipient, { x: px, y: py, amount: pressureAmount });
      }
      bond.last.set(a.id, { dx: p.ax - a.x, dy: p.ay - a.y, area: p.ar * p.ar - a.r * a.r, strength: w });
      bond.last.set(b.id, { dx: p.bx - b.x, dy: p.by - b.y, area: p.br * p.br - b.r * b.r, strength: w });
    });
    orphans.forEach(function (v, id) {
      var r = roots.get(id), w = 1 - ease((time - v.start) / EXIT);
      if (!r || w <= 0) { if (!frozen) orphans.delete(id); return; }
      write(out, r, r.x + v.dx * w, r.y + v.dy * w, Math.sqrt(Math.max(0, r.r * r.r + v.area * w)), v.strength * w);
      if (v.pressure && v.pressure.amount * w > 1e-8) pressures.set(id, { x: v.pressure.x, y: v.pressure.y, amount: v.pressure.amount * w });
    });
    this._time = time; this._previous = roots;
    var stats = this.stats; stats.bondCount = bonds.size; stats.entering = 0; stats.bonded = 0; stats.releasing = 0;
    bonds.forEach(function (b) { stats[b.phase]++; }); stats.orphanCount = orphans.size;
    return out;
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = CloudCohesion;
  root.CloudCohesion = CloudCohesion;
})(typeof window !== 'undefined' ? window : globalThis);
